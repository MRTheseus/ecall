package voicecall

import (
	"context"
	"fmt"
	"regexp"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/google/uuid"
	"github.com/iniwex5/vohive/internal/device"
	"github.com/iniwex5/vohive/pkg/logger"
)

// Manager 管理蜂窝语音呼叫生命周期、WebRTC 媒体网关与单例串口控制器
type Manager struct {
	mu            sync.RWMutex
	pool          *device.Pool
	currentCall   *CallSession
	audioBridge   *AudioBridge
	webrtcGW      *WebRTCGateway
	serialCtrl    *SerialController
	subscribers   map[chan CallEvent]struct{}
	subscribersMu sync.RWMutex
	stopTracker   chan struct{}
	trackerMu     sync.Mutex
}

func NewManager(pool *device.Pool) *Manager {
	bridge := NewAudioBridge("")
	gw := NewWebRTCGateway(bridge)
	
	// 动态获取设备的真实 AT 端口。大疆模组核�?AT 端口�?/dev/ttyUSB2
	atPort := "/dev/ttyUSB2"
	if pool != nil {
		if worker := pool.GetWorker("dji4g"); worker != nil {
			if resolved := worker.ResolvedATPort(); resolved != "" {
				atPort = resolved
			}
		}
	}
	
	sc := NewSerialController(atPort, 115200)

	m := &Manager{
		pool:        pool,
		audioBridge: bridge,
		webrtcGW:    gw,
		serialCtrl:  sc,
		subscribers: make(map[chan CallEvent]struct{}),
	}

	gw.onDisconnect = func() {
		logger.Info("WebRTC 连接断开，检查呼叫状�?)
	}

	// 绑定单例串口事件分发
	sc.OnIncoming = func(remoteNumber string) {
		m.handleSerialIncoming(remoteNumber)
	}
	sc.OnHangup = func(reason string) {
		m.handleSerialHangup(reason)
	}

	// 启动常驻串口监听�?	if err := sc.Start(context.Background()); err != nil {
		logger.Warn("启动单例串口监听器失�?, "err", err)
	}

	return m
}

func (m *Manager) handleSerialIncoming(remoteNumber string) {
	m.mu.Lock()
	defer m.mu.Unlock()

	// 如果当前正在通话中，跳过
	if m.currentCall != nil && m.currentCall.State != CallStateIdle && m.currentCall.State != CallStateTerminated {
		return
	}

	now := time.Now()
	sess := &CallSession{
		ID:           uuid.New().String(),
		DeviceID:     "dji4g",
		RemoteNumber: remoteNumber,
		Direction:    DirectionInbound,
		State:        CallStateRinging,
		StartedAt:    &now,
	}
	m.currentCall = sess
	logger.Info("检测到 4G 蜂窝来电", "number", remoteNumber)
	m.broadcastEventLocked("incoming", sess, "来电: "+remoteNumber)
}

func (m *Manager) handleSerialHangup(rawReason string) { go func() { m.mu.Lock(); defer m.mu.Unlock()

	if m.currentCall == nil || m.currentCall.State == CallStateIdle || m.currentCall.State == CallStateTerminated {
		return
	}

	reason := "call_ended"
	if m.currentCall.Direction == DirectionInbound && m.currentCall.State == CallStateRinging {
		reason = "remote_canceled" // 来电振铃中对方主动取�?	} else if m.currentCall.Direction == DirectionOutbound && (m.currentCall.State == CallStateDialing || m.currentCall.State == CallStateRinging) {
		if rawReason == "no_answer" {
			reason = "no_answer"
		} else {
			reason = "busy" // 呼出中对方拒接或占线
		}
	}

	logger.Info("串口捕获挂断信号，终止呼�?, "reason", reason, "raw_reason", rawReason)
	_ = m.hangupLocked(reason)
}()
}

// GetStatus 获取当前通话状�?func (m *Manager) GetStatus() *CallSession {
	m.mu.RLock()
	defer m.mu.RUnlock()

	if m.currentCall == nil {
		return &CallSession{
			State: CallStateIdle,
		}
	}
	copySession := *m.currentCall
	if copySession.ConnectedAt != nil && copySession.State == CallStateActive {
		copySession.DurationSec = int64(time.Since(*copySession.ConnectedAt).Seconds())
	}
	return &copySession
}

// Dial 发起呼叫
func (m *Manager) Dial(ctx context.Context, req DialRequest) (*CallSession, error) {
	m.mu.Lock()
	defer m.mu.Unlock()

	req.Number = strings.TrimSpace(req.Number)
	if req.Number == "" {
		return nil, fmt.Errorf("号码不能为空")
	}

	// 如果已有通话，先挂断
	if m.currentCall != nil && m.currentCall.State != CallStateIdle && m.currentCall.State != CallStateTerminated {
		_ = m.hangupLocked("new_dial")
	}

	now := time.Now()
	session := &CallSession{
		ID:           uuid.New().String(),
		DeviceID:     "dji4g",
		RemoteNumber: req.Number,
		Direction:    DirectionOutbound,
		State:        CallStateDialing,
		StartedAt:    &now,
	}
	m.currentCall = session

	// 关键改进：拨号瞬间立即启动音频通路，确保用户能听到基带传出的回铃音/彩铃/挂断�?	_ = m.audioBridge.Open(context.Background())

	// 发送拨号命令前，强行清理基带中可能残留的僵尸通话
	_, _ = m.serialCtrl.Execute("AT+CHUP", 2*time.Second)
	time.Sleep(200 * time.Millisecond)

	// 异步向模组发送拨号指令并启动状态跟�?	go func(target string, sessID string) {
		dialCmd := fmt.Sprintf("ATD%s;", target)
		logger.Info("执行 4G VoLTE 拨号", "number", target, "cmd", dialCmd)

		resp, err := m.serialCtrl.Execute(dialCmd, 8*time.Second)
		if err != nil || (!strings.Contains(resp, "OK") && !strings.Contains(resp, "CONNECT")) {
			logger.Warn("4G 拨号失败", "err", err, "resp", resp)
			m.mu.Lock()
			if m.currentCall != nil && m.currentCall.ID == sessID {
				m.currentCall.State = CallStateTerminated
				m.currentCall.HangupReason = "dial_failed"
				m.broadcastEventLocked("hangup", m.currentCall, "拨号失败: "+resp)
			}
			m.mu.Unlock()
			return
		}

		// 启动状态轮询跟踪器
		m.startCallTracker(sessID)
	}(req.Number, session.ID)

	m.broadcastEventLocked("state_change", session, "正在呼出...")
	return session, nil
}

// CLCCEntry 表示一�?AT+CLCC 呼叫信息
type CLCCEntry struct {
	Index  int
	Dir    int // 0: 呼出, 1: 呼入
	Stat   int // 0: Active, 1: Held, 2: Dialing, 3: Alerting, 4: Incoming, 5: Waiting
	Mode   int // 0: Voice, 1: Data, 2: Fax
	Number string
}

var clccRegex = regexp.MustCompile(`\+CLCC:\s*(\d+),(\d+),(\d+),(\d+),(\d+)(?:,"([^"]*)")?`)

func parseCLCC(output string) []CLCCEntry {
	var entries []CLCCEntry
	matches := clccRegex.FindAllStringSubmatch(output, -1)
	for _, m := range matches {
		if len(m) >= 6 {
			idx, _ := strconv.Atoi(m[1])
			dir, _ := strconv.Atoi(m[2])
			stat, _ := strconv.Atoi(m[3])
			mode, _ := strconv.Atoi(m[4])
			number := ""
			if len(m) >= 7 {
				number = strings.TrimSpace(m[6])
			}
			// 严格过滤：只解析 mode == 0 的语音电�?			if mode == 0 {
				entries = append(entries, CLCCEntry{
					Index:  idx,
					Dir:    dir,
					Stat:   stat,
					Mode:   mode,
					Number: number,
				})
			}
		}
	}
	return entries
}

// startCallTracker 启动状态追踪器
func (m *Manager) startCallTracker(sessID string) {
	m.trackerMu.Lock()
	if m.stopTracker != nil {
		close(m.stopTracker)
	}
	m.stopTracker = make(chan struct{})
	stopCh := m.stopTracker
	m.trackerMu.Unlock()

	go func() {
		ticker := time.NewTicker(500 * time.Millisecond)
		defer ticker.Stop()

		emptyCount := 0
		logger.Info("启动 AT+CLCC 呼叫状态追踪器", "session_id", sessID)

		for {
			select {
			case <-stopCh:
				logger.Info("呼叫状态追踪器停止", "session_id", sessID)
				return
			case <-ticker.C:
				m.mu.RLock()
				cur := m.currentCall
				m.mu.RUnlock()

				if cur == nil || cur.ID != sessID || cur.State == CallStateTerminated {
					return
				}

				resp, err := m.serialCtrl.Execute("AT+CLCC", 2*time.Second)
				if err != nil {
					logger.Warn("AT+CLCC 状态查询错�?, "err", err, "session_id", sessID)
					continue
				}

				entries := parseCLCC(resp)
				if len(entries) == 0 {
					emptyCount++
					// 连续 2 次无语音条目，判定通话已结�?					if emptyCount >= 2 {
						logger.Info("AT+CLCC 检测到语音通话已结�?被拒�?, "session_id", sessID)
						m.mu.Lock()
						if m.currentCall != nil && m.currentCall.ID == sessID {
							reason := "call_ended"
							if m.currentCall.Direction == DirectionInbound && m.currentCall.State == CallStateRinging {
								reason = "remote_canceled"
							} else if m.currentCall.Direction == DirectionOutbound && (m.currentCall.State == CallStateDialing || m.currentCall.State == CallStateRinging) {
								reason = "busy"
							}
							_ = m.hangupLocked(reason)
						}
						m.mu.Unlock()
						return
					}
					continue
				}

				emptyCount = 0
				entry := entries[0]

				m.mu.Lock()
				if m.currentCall != nil && m.currentCall.ID == sessID {
					switch entry.Stat {
					case 0: // Active (已接�?
						if m.currentCall.State != CallStateActive {
							now := time.Now()
							m.currentCall.State = CallStateActive
							m.currentCall.ConnectedAt = &now
							logger.Info("通话已接通，开始计�?, "session_id", sessID)
							m.broadcastEventLocked("state_change", m.currentCall, "通话已接�?)
						}
					case 3: // Alerting (对方振铃�?
						if m.currentCall.State != CallStateRinging {
							m.currentCall.State = CallStateRinging
							logger.Info("对方正在响铃", "session_id", sessID)
							m.broadcastEventLocked("state_change", m.currentCall, "对方正在响铃")
						}
					case 2: // Dialing (正在拨号)
						if m.currentCall.State == CallStateRinging {
							// 非法状态转移：已经响铃却退回到拨号，说明是基带的僵尸状态（大疆拒接Bug�?							logger.Warn("探测到非法状态转�?(3 -> 2)，判定为挂断", "session_id", sessID)
							_ = m.hangupLocked("busy")
							m.mu.Unlock()
							return
						}
						if m.currentCall.State != CallStateDialing {
							m.currentCall.State = CallStateDialing
							m.broadcastEventLocked("state_change", m.currentCall, "正在呼叫...")
						}
					case 6: // Disconnect (呼叫断开)
						logger.Info("对方已断开/拒接 (AT+CLCC stat=6)", "session_id", sessID)
						reason := "call_ended"
						if m.currentCall.Direction == DirectionOutbound && (m.currentCall.State == CallStateDialing || m.currentCall.State == CallStateRinging) {
							reason = "busy"
						}
						_ = m.hangupLocked(reason)
						m.mu.Unlock()
						return
					default:
						logger.Warn("AT+CLCC 发现未处理或异常状�?, "stat", entry.Stat, "session_id", sessID, "raw", resp)
					}
				}
				m.mu.Unlock()
			}
		}
	}()
}

// Answer 接听来电
func (m *Manager) Answer(ctx context.Context) (*CallSession, error) {
	m.mu.Lock()
	defer m.mu.Unlock()

	if m.currentCall == nil || m.currentCall.State != CallStateRinging {
		return nil, fmt.Errorf("当前没有来电振铃")
	}

	// 立即启动音频通路
	_ = m.audioBridge.Open(context.Background())

	// 发�?ATA 接听指令
	resp, err := m.serialCtrl.Execute("ATA", 8*time.Second)
	if err != nil || (!strings.Contains(resp, "OK") && !strings.Contains(resp, "CONNECT")) {
		return nil, fmt.Errorf("接听指令失败: %w, resp: %s", err, resp)
	}

	now := time.Now()
	m.currentCall.State = CallStateActive
	m.currentCall.ConnectedAt = &now

	// 启动通话追踪�?	m.startCallTracker(m.currentCall.ID)

	m.broadcastEventLocked("state_change", m.currentCall, "已接�?)
	return m.currentCall, nil
}

// Hangup 挂断通话
func (m *Manager) Hangup(ctx context.Context) error {
	m.mu.Lock()
	defer m.mu.Unlock()

	return m.hangupLocked("user_hangup")
}

func (m *Manager) hangupLocked(reason string) error {
	if m.currentCall == nil {
		return nil
	}

	m.trackerMu.Lock()
	if m.stopTracker != nil {
		close(m.stopTracker)
		m.stopTracker = nil
	}
	m.trackerMu.Unlock()

	// 发送挂断指�?	_, _ = m.serialCtrl.Execute("ATH", 4*time.Second)

	now := time.Now()
	m.currentCall.State = CallStateTerminated
	m.currentCall.EndedAt = &now
	m.currentCall.HangupReason = reason
	if m.currentCall.ConnectedAt != nil {
		m.currentCall.DurationSec = int64(now.Sub(*m.currentCall.ConnectedAt).Seconds())
	}

	_ = m.audioBridge.Close()
	m.webrtcGW.Close()

	m.broadcastEventLocked("hangup", m.currentCall, "通话已结�?)
	return nil
}

// SendDTMF 发送按键音
func (m *Manager) SendDTMF(ctx context.Context, digit string) error {
	m.mu.RLock()
	call := m.currentCall
	m.mu.RUnlock()

	if call == nil || call.State != CallStateActive {
		return fmt.Errorf("当前不在通话�?)
	}

	dtmfCmd := fmt.Sprintf("AT+VTS=\"%s\"", digit)
	_, err := m.serialCtrl.Execute(dtmfCmd, 5*time.Second)
	return err
}

// HandleWebRTCOffer 处理 WebRTC Offer
func (m *Manager) HandleWebRTCOffer(ctx context.Context, offerSDP string) (string, error) {
	return m.webrtcGW.HandleOffer(ctx, offerSDP)
}

// HandleICECandidate 处理 ICE Candidate
func (m *Manager) HandleICECandidate(candidate WebRTCCandidateRequest) error {
	return m.webrtcGW.AddICECandidate(webrtcCandidateInit(candidate))
}

// SubscribeEvents 订阅通话状态变更事件通道
func (m *Manager) SubscribeEvents() (chan CallEvent, func()) {
	ch := make(chan CallEvent, 16)
	m.subscribersMu.Lock()
	m.subscribers[ch] = struct{}{}
	m.subscribersMu.Unlock()

	status := m.GetStatus()
	ch <- CallEvent{
		Type:      "status",
		Session:   status,
		Timestamp: time.Now().UnixMilli(),
	}

	unsubscribe := func() {
		m.subscribersMu.Lock()
		delete(m.subscribers, ch)
		m.subscribersMu.Unlock()
		close(ch)
	}

	return ch, unsubscribe
}

func (m *Manager) broadcastEventLocked(eventType string, session *CallSession, msg string) {
	m.subscribersMu.RLock()
	defer m.subscribersMu.RUnlock()

	ev := CallEvent{
		Type:      eventType,
		Session:   session,
		Timestamp: time.Now().UnixMilli(),
		Message:   msg,
	}

	for ch := range m.subscribers {
		select {
		case ch <- ev:
		default:
		}
	}
}
